package data.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import data.dto.MemberDto;
import data.mapper.MemberMapper;

@Service
public class MemberService implements MemberServiceInter {
	
	@Autowired
	private MemberMapper memberMapper;

	@Override
	public void insertMember(MemberDto dto) {
		memberMapper.insertMember(dto);
	}

	@Override
	public List<MemberDto> getAllMembers() {
		return memberMapper.getAllMembers();
	}

	@Override
	public String getName(String id) {
		return memberMapper.getName(id);
	}

	@Override
	public int loginCheck(String id, String pass) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", id);
		map.put("pass", pass);
		return memberMapper.loginCheck(map);
	}


	@Override
	public void deleteMember(int num) {
		memberMapper.deleteMember(num);
	}
	@Override
	public int idCheck(String id) {
		return memberMapper.idCheck(id);
	}


}