package project.home.study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
