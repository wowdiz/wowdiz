package data.service;

import java.util.List;

import org.springframework.stereotype.Service;

import data.dto.MemberDto;

@Service
public interface MemberServiceInter {
	
	public void insertMember(MemberDto dto);
	public List<MemberDto> getAllMembers();
	public String getName(String id);
	public void deleteMember(int num);
	public int loginCheck(String id,String pass);
	public int idCheck(String id);

}

